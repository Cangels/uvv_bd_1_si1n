# **Primeiro Pset**
## Aluno: João Rafael Vieira Arcanjo
## Professor: Abrantes Araújo Silva Filho

Neste subdiretório está disponível a minha documentação sobre como foi feito esse PSET.

## PSET1

- GIT
    
    Primeiro eu tive que aprender o que é GIT e VCS(Version Control System), com uma explicação rápida o GIT seria nada mais nada menos que um VCS, que utilizamos para administrar diferentes tipos de versões de um projeto, logo essa explicação sobre GIT também diz que é VCS.

- GITHUB
   
   A diferença entre GITHUB e GIT é que o GITHUB é uma plataforma hospetada na WEB que utiliza o VCS do GIT, ela é muito fácil de mexer (principalmente se vc tiver um nível básico de inglês), você só terá uma estranhesa no começo por ser algo novo porém irá se acostumar muito rápido.
    Com o GITHUB eles utilizam também o MarkDown que é uma marcação de texto pura,  que foi inspirada no HTML, um exemplo de MarkDown é esse documento que você está lendo.

    Existe interfaces gráficas que pode se utilizar o GIT e GITHUB, como exemplo é a GitHub Desktop que é uma interface grátis.

-IMPLEMENTAÇÃO DO MODELO LÓGICO

   1.Essa parte eu realmente chorei, então vou separa-lá em duas partes. Na primeira foi aprender tudo sobre SCRIPTS que será tudo em SCRIPTS daqui pra frente, a tarefa se consistem em analisar uma imagem que o Abrantes disponibilizou para a gente, e refaze-la no SQL Power Architect, até então estava tudo dando certo, até que eu fui gerar o SCRIPT e me apareceu uma cacetada de erros, tempos pesquisando sobre o que poderia ser esses erros e por que eles estavam aparecendo, eu consigo resolve-los. Logo após isso fiz um leve configurada no sistema do Linux como o Abrantes tinha mostrado, para o banco de dados ter suporte para Português.
   
   2.Agora eu realmente tive um leve surto, pois eu já consegui criar o SCRIPT então imaginava que estava tudo certo para implementa-lo no Postgres, todavia eu estava completamente equivocado, por que o Abrantes pediu para criar um usuário e criar um banco de dados, e fazer com que o usuário criado fosse dono desse novo banco de dados e dentro dele criar um novo SCHEMA, e só depois disso tudo criar as tabelas, até lá foi tempo de pesquisa de como iria fazer isso e rodar em um SCRIPT, e eu consegui, só que eu ainda tinha um caminho pela frente, que seria inserir os dados da tabela hr do ORACLE, e lá vai eu surtar novamente para descobrir como que faz essa inserção sem ser uma por uma, depois de fazer os SELECT de maneira correta no ORACLE, eu consegui todos os dados e inseri normalmente no Postgres(mesmo tendo erros no SELECT que o Abrantes tinha disponibilizado).

-IMPLEMENTAÇÃO NO MARIADB
    
   Tudo que eu fiz na seção anterior, sobre criar usuário, tabela, inserir os dados, eu teria que fazer novamente no MariaDB, vou te ser sincero eu prefiro muito mais o Postgres, pois a interface grafíca dele me deixou mais familiarizado com os comandos e tive uma facilidade maior em pesquisar as coisas.



## Comentários sobre o PSET1
Realmente é algo desafiador que força os alunos a aprenderem e tirarem da cabeça informações que se fosse com provas não seriamos estimulados o bastante para aprender como eu aprendi fazendo esse PSET, só maluco faz isso em 2 3 dias, caso ele não possua nenhum conhecimento sobre bancos de dados, então espero que vocês tenham gostado dos comentários feitos.
